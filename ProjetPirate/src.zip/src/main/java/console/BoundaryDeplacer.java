package console;

import boundary.interfaces.IBoundary;
import boundary.interfaces.IDeplacerPirate;

public class BoundaryDeplacer implements IBoundary {
	
	private IDeplacerPirate controlDeplacer;
	
	public BoundaryDeplacer(IControlDeplacer controlDeplacer) {
		this.controlDeplacer = controlDeplacer;
	}
	
	public int deplacer(int somme, IDeplacerPirate controlDeplacer) {
		System.out.println("Le pirate se déplace de "+ somme +" cases.\n");
		
		
		System.out.println("La nouvelle position du joueur est " + newpos + ".\n");
		controlDeplacer.finDeplacerPirate();
		
		return newpos;
	}
	
	
	
	
	
	
}
